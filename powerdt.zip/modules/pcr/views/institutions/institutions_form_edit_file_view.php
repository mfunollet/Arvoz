<?php echo $this->element->get_file($this->element->field_upload, 'Download do Arquivo');?>
<?php echo $element->render_form($fields); ?>