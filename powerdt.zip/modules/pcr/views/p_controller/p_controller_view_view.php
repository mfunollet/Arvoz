<div id="items_view" class="">
    Email: <?php echo $element->email1 ?>    
</div>	
