<?php
class Log extends DataMapperExt {

	var $table = 'logs';

	function __construct($id = NULL)
	{
		parent::__construct($id);
	}

}
?>