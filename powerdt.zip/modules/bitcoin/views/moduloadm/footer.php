			</div>
            <div id="footer"></div>
		</div>
        <div id="conteiner-footer"></div>
        <hr size="1" />
        <div id="footer">
        	Partido Social Crist&atilde;o <?=date('Y', time());?>. Todos os direitos reservados.
        </div>
    </div>
</body>
</html>