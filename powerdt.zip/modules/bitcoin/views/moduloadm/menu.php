				<div id="menu">
                	<ul>
                    	<li class="menu-separador"><a href="<?php echo site_url('adm');?>">Home</a></li>
                        <li class="menu-separador"><a href="<?php echo site_url('adm/listar/conteudo');?>">Partido</a></li>
                    	<li class="menu-separador"><a href="<?php echo site_url('adm/listar/noticia');?>">Not&iacute;cias</a></li>
						<li class="menu-separador"><a href="<?php echo site_url('adm/listar/fotosalbum');?>">Fotos</a></li>
						<li class="menu-separador"><a href="<?php echo site_url('adm/listar/videosalbum');?>">V&iacute;deos</a></li>
						<li class="menu-separador"><a href="<?php echo site_url('adm/listar/artigo');?>">Artigos</a></li>
                    	<li class="menu-separador"><a href="<?php echo site_url('adm/listar/usuario');?>">Usu&aacute;rios</a></li>
                    	<li class="menu-separador"><a href="<?php echo site_url('adm/listar/grupo');?>">Grupos</a></li>						
                        <li class="menu-sair"><a href="<?php echo site_url('adm/logout');?>">Sair</a></li>
                    </ul>
                </div>
