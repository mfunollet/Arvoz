    <div id="rodape">
        <div id="conteudo_rodape">
          <p>
          <?=anchor('','Home')?> &nbsp;|&nbsp; 
          <?=anchor('modulos','M&oacute;dulos')?> &nbsp;|&nbsp; 
          <?=anchor('tecnologia','Tecnologia')?> &nbsp;|&nbsp; 
          <?=anchor('requisitos','Requisitos')?> &nbsp;|&nbsp; 
          <?=anchor('projetos','Projetos')?> &nbsp;|&nbsp; 
          <?=anchor('contato','Contato')?></p>
          <p id="copyright">
          	Uma solu&ccedil;&atilde;o customizada da <strong><a href="http://forpix.com.br"><em>forpix</em></a></strong> Design Ltda. 2004-2010. Marca registrada. Todos os direitos reservados.</p>
        </div>
    </div><!-- rodape -->
            
    </div><!-- conteudo -->
</div><!-- limites -->

</body>
</html>