<div class="progress progress-<?php echo get_color($clicks_percent, TRUE); ?>">
    <div class="bar" style="width: <?php echo $clicks_percent; ?>%">
        <?php echo $clicked; ?>/375
    </div>
</div>