<iframe name="topFrame" width="100%" height="150" src="<?php echo site_url('site/topclicker/'.$modo);?>"></iframe>
<iframe name="baseFrame" width="100%" height="700" src="#"></iframe>