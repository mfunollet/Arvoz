				<div id="sub-menu">
                	<h2>Hist&oacute;rico de modifica&ccedil;&otilde;es</h2>
                <!--	Sub-menu	-->
                </div>
		<div id="form" style="padding: 0 30px; margin: 15px 0;">
				<!--
				<div align="center">
					<p style="	color: #FF0000; font-weight: bold; font-size: 16px;"></p>
				</div>
				<br />-->
				<table width="100%">
					<thead> 
						<tr style="background: url(<?=base_url()?>inc/img/linha.gif) repeat-x; height: 20px;">
							<td><strong>Data</strong></td>
							<td><strong>Modifica&ccedil;&atilde;o</strong></td>
							<td><strong>Observa&ccedil;&atilde;o</strong></td>				
						</tr>
					</thead>
					<tbody>
						<tr style="background: url(<?=base_url()?>inc/img/linha.gif) repeat-x; height: 20px;">
							<td>15/03</td>
							<td>[Dev] Sistema de not&iacute;cias revisado e adaptado para slide show de destaques </td>
							<td>&nbsp;</td>				
						</tr>

						<tr style="background: url(<?=base_url()?>inc/img/linha.gif) repeat-x; height: 20px;">
							<td>13/03</td>
							<td>[Dev] Hist&oacute;rico de modifica&ccedil;&otilde;es adicionado a &aacute;rea administrativa </td>
							<td>&nbsp;</td>				
						</tr>

						<tr style="background: url(<?=base_url()?>inc/img/linha.gif) repeat-x; height: 20px;">
							<td>15/03</td>
							<td>[Man] Link de navega&ccedil;&atilde;o da &aacute;rea adminstrativa corrigido </td>
							<td>&nbsp;</td>				
						</tr>

						<tr style="background: url(<?=base_url()?>inc/img/linha.gif) repeat-x; height: 20px;">
							<td>12/03</td>
							<td>[Man] Programa&ccedil;&atilde;o otimizada para tempo de resposta do site </td>
							<td>Carregamento est&aacute; 70% mais eficiente </td>				
						</tr>

						<tr style="background: url(<?=base_url()?>inc/img/linha.gif) repeat-x; height: 20px;">
							<td>12/03</td>
							<td>[Dev] Adicionado "Link Externo" ao formul&aacute;rio  de inser&ccedil;&atilde;o de not&iacute;cias</td>
							<td></td>				
						</tr>

						<tr style="background: url(<?=base_url()?>inc/img/linha.gif) repeat-x; height: 20px;">
							<td>12/03</td>
							<td>[Man] Link de logout da se&ccedil;&atilde;o admistrativa </td>
							<td>&nbsp;</td>				
						</tr>

						<tr style="background: url(<?=base_url()?>inc/img/linha.gif) repeat-x; height: 20px;">
							<td>12/03</td>
							<td>[Dev] Formul&aacute;rio de &quot;Informe-se&quot; otimizado </td>
							<td>&nbsp;</td>				
						</tr>

						<tr style="background: url(<?=base_url()?>inc/img/linha.gif) repeat-x; height: 20px;">
							<td>12/03</td>
							<td>[Dev] Link de logout da se&ccedil;&atilde;o admistrativa </td>
							<td>&nbsp;</td>				
						</tr>

						<tr style="background: url(<?=base_url()?>inc/img/linha.gif) repeat-x; height: 20px;">
							<td>12/03</td>
							<td>[Man] Link de logout da se&ccedil;&atilde;o admistrativa </td>
							<td>&nbsp;</td>				
						</tr>

						<tr style="background: url(<?=base_url()?>inc/img/linha.gif) repeat-x; height: 20px;">
							<td>12/03</td>
							<td>[Man] Link de logout da se&ccedil;&atilde;o admistrativa </td>
							<td>&nbsp;</td>				
						</tr>
					</tbody>
				</table>
				<br />
				<em>Legenda:<br />
				Dev: desenvolvimento<br />
				Man: Manunten&ccedil;&atilde;o</em>			</div>
