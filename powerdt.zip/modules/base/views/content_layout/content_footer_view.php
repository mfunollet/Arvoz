            </div> <!-- Span12 End-->
<?php $this->load->view('base/footer_view', $data); ?>     

