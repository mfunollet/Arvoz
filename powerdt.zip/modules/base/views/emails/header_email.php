<div style="background:whiteSmoke;padding:20px;font-family:Verdana,Arial,Helvetica,sans-serif;color:rgb(0, 0, 0);">
<table style="width:600px;margin:15px auto 0;background:#fff;border:1px solid #E7E7E7;margin-bottom:15px">
    <tbody>
        <tr style="margin-bottom:10px;" cellpadding='0' cellspacing='0'>
            <td colspan="2" style="padding: 10px; border-bottom: 5px solid whitesmoke; text-align: center;">
				<img alt="<?php echo lang('app_slogan') ?>" width="250" src="<?php echo base_url() ?>images/app_logo_horizontal.png"> 
            </td>
        </tr>
        <tr style="clear:both;">
            <td colspan="2" style="clear:both; border-bottom: 4px solid whitesmoke">
				<div style="padding:10px;text-align:justify">
					