				
</div>
</td>
</tr>
<tr style="border-top: 1px solid #999">
    <td style="padding:0px;background:#fff;clear:both text-align:left" colspan="2">	
        <div style="padding:10px;text-align:justify">					
            <p style="text-align:justify">
                <?php echo $this->config->item('app_address'); ?>
            </p>	
        </div>
    </td>
</tr>

</tbody>
</table>
</div>





