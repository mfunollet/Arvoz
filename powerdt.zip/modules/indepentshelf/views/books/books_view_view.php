<div id="items_view">
    Title: <?php echo $element->title ?><br />
    <br /><br />
    <h3>Autor:</h3>
    <?php echo $element->person->first_name;?>
</div>	
