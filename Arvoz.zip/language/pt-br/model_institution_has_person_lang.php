<?php
// Language File for Institution_has_person Model

$lang['institution_has_person_person'] = 'Pessoa';
$lang['institution_has_person_role'] = 'Papel';
$lang['institution_has_person_job'] = 'Função';
$lang['institution_has_person_start_date'] = 'Data de início';
$lang['institution_has_person_end_date'] = 'Data de término';


/* End of file model_institution_has_person_lang.php */
/* Location: ./application/language/pt-br/model_institution_has_person_lang.php */