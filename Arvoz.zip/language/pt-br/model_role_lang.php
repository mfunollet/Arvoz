<?php
// Language File for Role Model

$lang['role_name'] = 'Papel';


/* End of file model_role_lang.php */
/* Location: ./application/language/pt-br/model_role_lang.php */