<?php
// Language File for Company_has_person Model

$lang['company_has_person_person'] = 'Pessoa';
$lang['company_has_person_company'] = 'Empreendimento';
$lang['company_has_person_role'] = 'Papel';
$lang['company_has_person_job'] = 'Função';
$lang['company_has_person_start_date'] = 'Data de início';
$lang['company_has_person_end_date'] = 'Data de término';


/* End of file model_company_has_person_lang.php */
/* Location: ./application/language/pt-br/model_company_has_person_lang.php */