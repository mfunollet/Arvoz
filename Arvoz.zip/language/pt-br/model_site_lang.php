<?php
// Language File for Site Model

$lang['site_name'] = 'Nome';
$lang['site_url'] = 'URL';


/* End of file model_site_lang.php */
/* Location: ./application/language/pt-br/model_site_lang.php */