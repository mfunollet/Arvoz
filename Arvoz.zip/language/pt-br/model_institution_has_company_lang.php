<?php
// Language File for Institution_has_company Model

$lang['institution_has_company_company'] = 'Empresa';
$lang['institution_has_company_start_date'] = 'Data de início';
$lang['institution_has_company_end_date'] = 'Data de término';


/* End of file model_institution_has_company_lang.php */
/* Location: ./application/language/pt-br/model_institution_has_company_lang.php */