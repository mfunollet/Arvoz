<?php

/* End of file datamapper_lang.php */
/* Location: ./application/language/pt_BR/datamapper_lang.php */
