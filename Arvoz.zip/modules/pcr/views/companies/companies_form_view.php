<script type="text/javascript">var ctrlr = "<?php echo $ctrlr;?>"</script>
<?php echo $element->render_form($fields); ?>