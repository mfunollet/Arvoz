    </div> <!-- Row End-->
    <div class="modal fade" id="myModal"></div>
    <div id="footer" class="row-fluid">
        <div class="span12">
        </div>
    </div>
</div> <!-- Container End -->			
</body>
</html>