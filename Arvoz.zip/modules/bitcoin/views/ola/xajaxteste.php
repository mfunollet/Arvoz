<form id="form_teste">
<input type="text" name="campo_email" id="campo_email" class="campo_texto">
<input type="button" value="Adicionar" class="botao_lista botao_adicionar" name="btn_login" onclick="javascript:xajax_addIt('campo_email','bloco_email',xajax.getFormValues('form_teste'));">
<div id="bloco_email" class="span_contato"></div>