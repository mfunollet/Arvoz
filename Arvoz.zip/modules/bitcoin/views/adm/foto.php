				<div id="sub-menu">
                	<h2>Enviar foto</h2>
                <!--	Sub-menu	-->
                </div>
             
                <div id="form" style="padding: 0 30px; margin: 15px 0;">
                    <?=$f->render_form($campos,$url)?>
                </div>