<div id="alerts" style="display: none"></div>
<h2>Em breve</h2>
<u>Auto Atacar Forçado</u> - (Rastrear + Ataque de 10 turnos no inimigo com melhor Gold/ArmySize)<br />
<u>Auto Atacar Criterioso</u> - (O mesmo que o de cima, mas só executa o ataque se a quantidade de gold no final for maior que 30 vezes o seu incoming)<br />
[O resultado da luta pode ser visto no Log do DT]
