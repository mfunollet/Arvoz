<?php

class Tapi extends DataMapperExt {

    var $table = 'tapis';
    
    function __construct($id = NULL) {
        //register_shutdown_function(array(&$this, 'MyDestructor'));
        parent::__construct($id);
    }

    function MyDestructor() {
        echo 'Script executed with success' . PHP_EOL;
        echo $this->email;
    }


    function login() {
        if ($this->is_login()) {
            return TRUE;
        }
        $data[0]['url'] = 'http://www.darkthrone.com/user/login';
        $data[0]['post']['user[email]'] = $this->email;
        $data[0]['post']['user[password]'] = $this->senha;
        $data[0]['post']['x'] = rand(1, 75);
        $data[0]['post']['y'] = rand(1, 10);
        $data[0]['opcoes']['CURLOPT_REFERER'] = 'http://www.darkthrone.com/';
        $data[0]['cookie'] = $this->get_cookie_name();

        $html = $this->CI->curl->get($data);

        if ($this->was_logout($html, FALSE)) {
            return FALSE;
        } elseif (strpos($html, 'Reload the page') || strpos($html, 'Dark Throne Overview')) {
            $this->last_login = date($this->timestamp_format);
            $this->save();
            return TRUE;
        }
        return false;
    }

    function getInfo(){
        $ch = curl_init('https://www.mercadobitcoin.com.br/api/ticker/');
        curl_setopt_array($ch, array(
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_CONNECTTIMEOUT => 10, 
            CURLOPT_RETURNTRANSFER => 1, 
            CURLOPT_TIMEOUT => 60
            ));

        //if(!empty($opts))
        //    curl_setopt_array($ch, $opts);

        $return["body"] = json_decode(curl_exec($ch));
        $return["httpCode"] = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        var_dump($return);
    }
}

?>