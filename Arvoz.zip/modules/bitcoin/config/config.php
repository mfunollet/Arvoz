<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['admin_email'] = 'arvorz@teste.com';
$config['site_title'] = 'PowerDarkThrone';
$config['app_name'] = 'Power DarkThrone';

$config['max_num_items_on_page'] = '10';