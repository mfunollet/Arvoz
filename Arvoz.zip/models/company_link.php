<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of company_link
 *
 * @author thomas
 */
class Company_link {
    var $has_many = array();
}

?>
